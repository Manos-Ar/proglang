import java.util.*;

public class ZtallocState {
	private int l, r, tl, tr;
	private StringBuilder path;

	public ZtallocState(int a, int b, StringBuilder p){
		l = a;
		r = b;
		path = p;
	}

	public int get_l(){
		return l;
	}

	public int get_r(){
		return r;
	}

	public StringBuilder get_path(){
		return path;
	}

	public boolean isFinal(int tl, int tr){
		if(l>= tl && r<=tr) return true;
		return false;
	}

	public boolean isBad(){
		if(r>999999) return true;
		return false;
	}

	public ArrayList<ZtallocState> next(){
		ArrayList<ZtallocState> states = new ArrayList<>();
		StringBuilder a = new StringBuilder(path.toString());
		a.append("h");
		states.add(new ZtallocState(l/2, r/2, a));
		StringBuilder b = new StringBuilder(path.toString());
		b.append("t");
		states.add(new ZtallocState(3*l+1, 3*r+1, b));
		return states;
	}

	@Override
	public boolean equals(Object o){
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		ZtallocState other = (ZtallocState) o;
		return l==other.l && r==other.r;
	}

	public long hash(){
		long a = l+r;
		return a*(a+1)/2 + l;
	}

	@Override
	public String toString(){
		StringBuilder sb = new StringBuilder("");
		sb.append(String.valueOf(l));
		sb.append(" ");
		sb.append(String.valueOf(r));
		sb.append(" ");
		sb.append(path.toString());
		return sb.toString();
	}
}