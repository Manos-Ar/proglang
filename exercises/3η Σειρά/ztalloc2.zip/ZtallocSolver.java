import java.util.*;

public class ZtallocSolver{
	public ZtallocState solve(ZtallocState initial, int tl, int tr){
		Dictionary<Long, Byte> seen = new Hashtable<Long, Byte>();
        Queue<ZtallocState> remaining = new ArrayDeque<>();
        remaining.add(initial);
        seen.put(initial.hash(),(byte) 1);
        while(!remaining.isEmpty()){
        	ZtallocState s = remaining.remove();
        	if(s.isFinal(tl, tr)) return s;
        	ArrayList<ZtallocState> a = s.next();
        	for(int i=0; i<2; i++){
                ZtallocState x = a.get(i);
                long b = x.hash();
        		if(seen.get(b)==null && !x.isBad()){
                    remaining.add(x);
                    seen.put(b, (byte) 1);
                }
        	}
        }
        return null;
	}
}