import java.util.Scanner;
import java.io.File;
import java.io.IOException;

public class Ztalloc{
	public static void main(String[] args){
		try{
			Scanner scanner = new Scanner(new File(args[0]));
			int a = scanner.nextInt();
			for(int i=0; i<a; i++){
				int l = scanner.nextInt();
				int r = scanner.nextInt();
				int tl = scanner.nextInt();
				int tr = scanner.nextInt();
				ZtallocSolver s = new ZtallocSolver();
				ZtallocState initial = new ZtallocState(l, r, new StringBuilder(""));
				ZtallocState result = s.solve(initial, tl, tr);
				if(result == null)
					System.out.println("IMPOSSIBLE");
				else if(result.get_path().length() == 0)
					System.out.println("EMPTY");
				else
					System.out.println(result.get_path().toString());
			}
		}
		catch (IOException e){
			System.out.println("An error occurred.");
			e.printStackTrace(); 
		}
	}
}